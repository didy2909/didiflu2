package io.flutter.plugins.firebase.auth.example

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
