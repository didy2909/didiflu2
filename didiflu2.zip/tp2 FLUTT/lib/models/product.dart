class Product {
  Product({
    this.id,
    required this.name,
    required this.price,
  });

  final String? id;
  final String name;
  final double price;

  factory Product.fromMap(String id, Map<String, dynamic> data) {
    return Product(
      id: id,
      name: data['name'] as String? ?? '',
      price: (data['price'] as num?)?.toDouble() ?? 0,
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'name': name,
      'price': price,
      'createdAt': DateTime.now(),
    };
  }
}
