import 'package:firebase_auth/firebase_auth.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:twitter_login/twitter_login.dart';

class AuthService {
  static const prefLoggedInKey = 'loggedIn';

  static final AuthService instance = AuthService._internal();

  AuthService._internal();

  final FirebaseAuth _auth = FirebaseAuth.instance;

  Future<UserCredential> signUpWithEmail({
    required String email,
    required String password,
  }) async {
    final cred = await _auth.createUserWithEmailAndPassword(
      email: email,
      password: password,
    );
    await _setLoggedIn(true);
    return cred;
  }

  Future<UserCredential> signInWithEmail({
    required String email,
    required String password,
  }) async {
    final cred = await _auth.signInWithEmailAndPassword(
      email: email,
      password: password,
    );
    await _setLoggedIn(true);
    return cred;
  }

  Future<UserCredential> signInWithGoogle() async {
    final googleUser = await GoogleSignIn().signIn();
    if (googleUser == null) {
      throw FirebaseAuthException(
        code: 'aborted',
        message: 'Connexion Google annulée',
      );
    }
    final googleAuth = await googleUser.authentication;
    final credential = GoogleAuthProvider.credential(
      accessToken: googleAuth.accessToken,
      idToken: googleAuth.idToken,
    );
    final cred = await _auth.signInWithCredential(credential);
    await _setLoggedIn(true);
    return cred;
  }

  /// TODO: Remplace les valeurs par tes clés d'API Twitter (X) et l'URI de callback.
  static const _twitterApiKey = 'YOUR_TWITTER_API_KEY';
  static const _twitterApiSecret = 'YOUR_TWITTER_API_SECRET';
  static const _twitterRedirectUri = 'YOUR_TWITTER_REDIRECT_URI';

  Future<UserCredential> signInWithTwitter() async {
    final twitterLogin = TwitterLogin(
      apiKey: _twitterApiKey,
      apiSecretKey: _twitterApiSecret,
      redirectURI: _twitterRedirectUri,
    );

    final authResult = await twitterLogin.login();
    if (authResult.authToken == null || authResult.authTokenSecret == null) {
      throw FirebaseAuthException(
        code: 'aborted',
        message: 'Connexion Twitter annulée',
      );
    }

    final credential = TwitterAuthProvider.credential(
      accessToken: authResult.authToken!,
      secret: authResult.authTokenSecret!,
    );
    final cred = await _auth.signInWithCredential(credential);
    await _setLoggedIn(true);
    return cred;
  }

  Future<void> logout() async {
    await _auth.signOut();
    await GoogleSignIn().signOut();
    await _setLoggedIn(false);
  }

  Future<void> _setLoggedIn(bool value) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool(prefLoggedInKey, value);
  }
}
