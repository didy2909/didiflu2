import 'package:cloud_firestore/cloud_firestore.dart';

import '../models/product.dart';

class ProductService {
  static final ProductService instance = ProductService._internal();

  ProductService._internal();

  final _collection = FirebaseFirestore.instance.collection('products');

  Stream<List<Product>> streamProducts() {
    return _collection.orderBy('createdAt', descending: true).snapshots().map(
          (snap) => snap.docs
              .map((doc) => Product.fromMap(doc.id, doc.data()))
              .toList(),
        );
  }

  Future<void> addProduct(Product product) async {
    await _collection.add(product.toMap());
  }
}
