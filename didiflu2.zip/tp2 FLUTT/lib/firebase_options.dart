import 'package:firebase_core/firebase_core.dart';

/// TODO: Remplace les valeurs par celles générées via `flutterfire configure`.
class DefaultFirebaseOptions {
  static FirebaseOptions get currentPlatform => const FirebaseOptions(
        apiKey: 'REPLACE_ME',
        appId: 'REPLACE_ME',
        messagingSenderId: 'REPLACE_ME',
        projectId: 'REPLACE_ME',
        storageBucket: 'REPLACE_ME',
      );
}
